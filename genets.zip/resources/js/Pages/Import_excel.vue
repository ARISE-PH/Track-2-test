<template>
    <Head title="Import File" />

    <BreezeAuthenticatedLayout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Import File
            </h2>
        </template>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="mb-8 bg-white shadow-sm sm:rounded-lg p-4">
                    <form method="post" enctype="multipart/form-data" ref="excel_file" class="flex items-center">
                        <div class="flex-1">
                            <label class="mr-2 font-bold flex items-center">
                                <template v-if="form.file">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                                    </svg>
                                    <span class="ml-2" v-text="form.file.name"/>
                                </template>
                                <template v-else>
                                    <span>Import an excel file</span>
                                </template>
                            </label>
                            <input type="hidden" name="_token" :value="token" />
                            <input name="import_file" id="import_file" type="file" @input="form.file = $event.target.files[0]" class="mb-2 absolute top-0 left-0 opacity-0" @change="onFileChange" />
                        </div>
                        <div class="flex-none">
                            <label type="button" for="import_file" class="cursor-pointer font-bold inline-flex items-center justify-center px-4 py-2 text-base font-medium leading-6 text-white whitespace-no-wrap bg-purple-500 border border-purple-600 rounded-md shadow-sm hover:bg-purple-600 hover:border-purple-700 focus:outline-none focus:shadow-none">
                                {{ form.file ? 'Change File' : 'Add a File' }}
                            </label>
                        </div>
                    </form>
                </div>
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="flex flex-col">
                        <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                            <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                                <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                                    <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                <span role="button" class="cursor-pointer" @click="sortBy('Member_ID')">Member ID</span>
                                            </th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                <span role="button" class="cursor-pointer" @click="sortBy('Member_Name')">Member Name</span>
                                            </th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                <span role="button" class="cursor-pointer" @click="sortBy('Project_ID')">Project ID</span>
                                            </th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                <span role="button" class="cursor-pointer" @click="sortBy('Project_Title')">Project Title</span>
                                            </th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                <span role="button" class="cursor-pointer" @click="sortBy('Project_Description')">Project Description</span>
                                            </th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                <span role="button" class="cursor-pointer" @click="sortBy('Location')">Location</span>
                                            </th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                <span role="button" class="cursor-pointer" @click="sortBy('Target_Start_Date')">Target Start Date</span>
                                            </th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                <span role="button" class="cursor-pointer" @click="sortBy('Target_End_Date')">Target End Date</span>
                                            </th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                <span role="button" class="cursor-pointer" @click="sortBy('Actual_Start_Date')">Actual Start Date</span>
                                            </th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                <span role="button" class="cursor-pointer" @click="sortBy('Actual_End_Date')">Actual End Date</span>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <tr v-for="list in data" :key="list.id">
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                {{list.Member_ID}}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                {{list.Member_Name}}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                {{list.Project_ID}}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                {{list.Project_Title}}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                {{list.Project_Description}}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                {{list.Location}}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                {{list.Target_Start_Date}}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                {{list.Target_End_Date}}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                {{list.Actual_Start_Date}}
                                            </td>
                                             <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                {{list.Actual_End_Date}}
                                            </td>
                                        </tr>
                                    </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </BreezeAuthenticatedLayout>
</template>

<script>
import BreezeAuthenticatedLayout from '@/Layouts/Authenticated.vue'
import { Head } from '@inertiajs/inertia-vue3';
import { Inertia } from '@inertiajs/inertia';
import { useForm } from '@inertiajs/inertia-vue3'

export default {
    components: {
        BreezeAuthenticatedLayout,
        Head,
    },
    props: {
        data: Object.data,
        route_slug: Object.route_slug,
        token: Object.token
    },
    setup ( props ) {
        const form = useForm({
            file: null
        })

        let sortDirection = 'asc'
        let sortFilter = 'Member_ID'

        function onFileChange () {
            const formData = new FormData()
            formData.append('import_file', form.file)
            try {
                Inertia.post(route('excel.store'), formData, {
                    forceFormData: true,
                })
            } catch (error) {
                console.log(error)
            }
        }

        function sortBy (key) {
            sortFilter = key
            props.data.sort((a, b) => {
                if (a[key] < b[key]) {
                    return sortDirection === 'asc' ? -1 : 1
                }
                if (a[key] > b[key]) {
                    return sortDirection === 'asc' ? 1 : -1
                }
                return 0
            })
        }

        return { form, onFileChange, sortBy }
    },
 

}
</script>
